(function(){

    function newChatControl(){
  
        const chat = {};
        let fullMode = false;
        let showFooter = false;
        let pagination = page.pagination();
        let listView;
        let treeView;
        let altView;

        function getChatTopMenuView(){

         return [];
        }

        function getSplitContainerView(){
          let splitLeft = "";
          if(!fullMode) splitLeft = getSplitLeftContainerView();
          return m("div", {class: "results-fixed", onselectstart: function(e){ e.preventDefault();}},
            m("div", {class: "splitcontainer"}, [
              splitLeft,
              getSplitRightContainerView()
            ])
          );
        }

        function getSplitRightContainerView(){
          let cls = "splitrightcontainer";
          if(fullMode) cls = "splitfullcontainer";
          return m("div", {class: cls}, [
              getResultsView()     
          ]);
        }

        function getSplitLeftContainerView(){

          return m("div", {
            class: "splitleftcontainer",
            ondragover: function(e){
              e.preventDefault();
            }
          }, [
              m("div", {}, "Chat History")
          ]);
        }
        function getResultsView(){
          let ret = m("div", {class: "overflow-y-auto"}, [
            m("div", {class: "bg-white user-info-header px-5 py-3"},
              m("div", {class: "flex justify-between"}, [
                m("div", {class: "flex items-center"}, [
                  m("span", {class: "material-icons-outlined"}, "woman"),
                  m("h3", {class: "text-gray-400 tex-md pl-4"}, "Woman")
                ]),
                m("div", [
                  m("i", {class: "material-icons text-violet-300"}, "chat")
                ])
              ])
            ),
            m("div", {class: "relative receive-chat flex justify-start"},
              m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
                m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
                m("p", "Here is the text")
              )
            ),
            m("div", {class: "relative receive-chat flex justify-end"},
              m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
              m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
                m("p", "Here is the text")
              )
            ),
            m("div", {class: "relative receive-chat flex justify-start"},
            m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
              m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
              m("p", "Here is the text")
            )
          ),
          m("div", {class: "relative receive-chat flex justify-end"},
            m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
            m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
              m("p", "Here is the text")
            )
          ),
          m("div", {class: "relative receive-chat flex justify-start"},
          m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
            m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
            m("p", "Here is the text")
          )
        ),
        m("div", {class: "relative receive-chat flex justify-end"},
          m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
          m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
            m("p", "Here is the text")
          )
        ),
        m("div", {class: "relative receive-chat flex justify-start"},
        m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
          m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
          m("p", "Here is the text")
        )
      ),
      m("div", {class: "relative receive-chat flex justify-end"},
        m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
        m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
          m("p", "Here is the text")
        )
      )
            /*
            ,
            m("div", {class: "bg-gray-100 fixed bottom-0 w-full pl-4"},
              m("textarea", {class: "w-full bg-gray-100 pt-3 h-12 focus:outline-none font-light", placeholder: "Message"})
            )
            */
          ]);
          /*
          <div class="">


          
        <div class="bg-gray-100 fixed bottom-0 w-full pl-4">
          <textarea class="w-full bg-gray-100 pt-3 h-12 focus:outline-none font-light" placeholder="Write a message"></textarea>
        </div> <!-- Footer message -->
      </div>
    </div>

          */
          //let mtx = treeView.selectedNode();
          //if(!mtx) return ret;
           // return m("div", {}, "Chat View");
           return ret;
        }

        function getChatBottomMenuView(){
          // if(!showFooter) return "";
          return m("div", {class: "result-nav-outer"}, 
            m("div", {class: "results-fixed"},
            m("div", {class: "splitcontainer"}, [
              m("div", {class: "splitleftcontainer"}, "..."),
              m("div", {class: "splitrightcontainer"}, 
                m("textarea", {class: "w-full bg-gray-100 pt-3 h-12 focus:outline-none font-light", placeholder: "Message"})

              )
            ]),
          )
          );
          /*
          return m("div", {class: "result-nav-outer"}, 
            m("div", {class: "result-nav-inner"}, [
              m("div", {class: "result-nav"}, "..."),
              m("div", {class: "result-nav"}, "Bottom")
            ])
          );
          */
        }
      
        function getChatView(vnode){
            return m("div",{class : "content-outer"},[
              (fullMode ? "" : m(page.components.navigation, {hideBreadcrumb: true})),
              m("div",{class : "content-main"},
                m("div", {class: "list-results-container"},
                  m("div", {class: "list-results"}, [
                    getChatTopMenuView(),
                    getSplitContainerView(),
                    getChatBottomMenuView()
                  ])
                )
              )
            ]);
        }
        chat.toggleFullMode = function(){
          fullMode = !fullMode;
          m.redraw();
        }
        chat.cancelView = function(){
          altView = undefined;
          fullMode = false;
          m.redraw();
        };
        chat.editItem = function(object){
          if(!object) return;
          console.log("Edit", object);
          altView = {
            fullMode,
            view: page.views.object(),
            type: object.model,
            containerId: object.objectId
          };
          m.redraw();
        };
        chat.addNew = function(type, containerId, parentNew){
          altView = {
            fullMode,
            view: page.views.object(),
            type,
            containerId,
            parentNew,
            new: true
          };
          m.redraw();
        };
        chat.view = {
            oninit : function(vnode){
                let ctx = page.user.homeDirectory;
                origin = vnode.attrs.origin || ctx;
            },
            oncreate : function (x) {
              // app = page.space(entityName, x, pagination.entity);
            },
            onupdate : function(x){

            },
            onremove : function(x){
              // document.documentElement.removeEventListener("keydown", navListKey);
              page.navigable.cleanupContextMenus();
              pagination.stop();
              // if(app) app.destroy();
            },
  
            view: function (vnode) {
              let v = getChatView(vnode);
                return [v, page.loadDialog()];
            }
        };
        return chat;
    }
      page.views.chat = newChatControl;
  }());
  