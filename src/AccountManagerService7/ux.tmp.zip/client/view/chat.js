(function(){

    function newChatControl(){
  
        const chat = {};
        let fullMode = false;
        let showFooter = false;
        let pagination = page.pagination();
        let listView;
        let treeView;
        let altView;

        function getChatTopMenuView(){

         return [];
        }

        function getSplitContainerView(){
          let splitLeft = "";
          if(!fullMode) splitLeft = getSplitLeftContainerView();
          return m("div", {class: "results-fixed", onselectstart: function(e){ e.preventDefault();}},
            m("div", {class: "splitcontainer"}, [
              splitLeft,
              getSplitRightContainerView()
            ])
          );
        }

        function getSplitRightContainerView(){
          let cls = "splitrightcontainer";
          if(fullMode) cls = "splitfullcontainer";
          return m("div", {class: cls}, [
              getResultsView()     
          ]);
        }

        function getSplitLeftContainerView(){

          return m("div", {
            class: "splitleftcontainer",
            ondragover: function(e){
              e.preventDefault();
            }
          }, [
              m("div", {}, "Chat History")
          ]);
        }
        function getResultsView(){
          let ret = "";
          //let mtx = treeView.selectedNode();
          //if(!mtx) return ret;
            return m("div", {}, "Chat View");
        }

        function getChatBottomMenuView(){
          if(!showFooter) return "";

          return m("div", {class: "result-nav-outer"}, 
            m("div", {class: "result-nav-inner"}, [
              m("div", {class: "result-nav"}, "..."),
              m("div", {class: "result-nav"}, "Bottom")
            ])
          );
        }
      
        function getChatView(vnode){
            return m("div",{class : "content-outer"},[
              (fullMode ? "" : m(page.components.navigation, {hideBreadcrumb: true})),
              m("div",{class : "content-main"},
                m("div", {class: "list-results-container"},
                  m("div", {class: "list-results"}, [
                    getChatTopMenuView(),
                    getSplitContainerView(),
                    getChatBottomMenuView()
                  ])
                )
              )
            ]);
        }
        chat.toggleFullMode = function(){
          fullMode = !fullMode;
          m.redraw();
        }
        chat.cancelView = function(){
          altView = undefined;
          fullMode = false;
          m.redraw();
        };
        chat.editItem = function(object){
          if(!object) return;
          console.log("Edit", object);
          altView = {
            fullMode,
            view: page.views.object(),
            type: object.model,
            containerId: object.objectId
          };
          m.redraw();
        };
        chat.addNew = function(type, containerId, parentNew){
          altView = {
            fullMode,
            view: page.views.object(),
            type,
            containerId,
            parentNew,
            new: true
          };
          m.redraw();
        };
        chat.view = {
            oninit : function(vnode){
                let ctx = page.user.homeDirectory;
                origin = vnode.attrs.origin || ctx;
            },
            oncreate : function (x) {
              // app = page.space(entityName, x, pagination.entity);
            },
            onupdate : function(x){

            },
            onremove : function(x){
              // document.documentElement.removeEventListener("keydown", navListKey);
              page.navigable.cleanupContextMenus();
              pagination.stop();
              // if(app) app.destroy();
            },
  
            view: function (vnode) {
              let v = getChatView(vnode);
                return [v, page.loadDialog()];
            }
        };
        return chat;
    }
      page.views.chat = newChatControl;
  }());
  