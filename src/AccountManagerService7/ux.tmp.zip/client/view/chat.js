(function(){

    function newChatControl(){
  
        const chat = {};
        let fullMode = false;
        let showFooter = false;
        let pagination = page.pagination();
        let listView;
        let treeView;
        let altView;


        am7model.models.push({
          name: "chatSettings",
          icon: "chat",
          label: "settings",
          fields: [
              {name: "system", type: "model", baseModel: "olio.charPerson", default: "Ark"},
              {name: "user", type: "model", baseModel: "olio.charPerson", default: "Laurel"},
              {name: "assist", type: "boolean", default: true},
              {name: "rating", type: "list", default: "E"}
          ]
      });

      am7model.forms.chatSettings = {
        label : "Settings",
        commands : {
          peek : {
            label : 'Peek',
            icon : 'man',
            action : 'peek'
        },
          chat : {
              label : 'Chat',
              icon : 'chat',
              action : 'chat'
          }
      },
        fields: {
            system: {
                layout: "full",
                format: "text",
                label: "System"
                /*
                field: {
                  format: "picker",
                  pickerType: "olio.charPerson",
                  pickerProperty: {
                      selected: "{object}",
                      entity: "system"
                  }
              }
              */
            },
            user: {
              layout: "full",
              format: "text",
              label: "User"
              /*
              field: {
                format: "picker",
                pickerType: "olio.charPerson",
                pickerProperty: {
                    selected: "{object}",
                    entity: "user"
                }
            }
              */
          },
          assist: {
                layout: "half",
                label: "Assist",
                type: "boolean"
            },
          rating: {
            type: "list",
            layout: "half",
            label: "Rating",
            format: "list",
            values : ["E", "E10", "T", "M", "AO", "RC"]
          }
        }
    };
    let chatCfg = {
      system: undefined,
      user: undefined,
      peek: false,
      history: undefined,
      pending: false
    };
    let inst = am7model.newInstance("chatSettings", am7model.forms.chatSettings);
    window.dbgInst = inst;
    inst.action("peek", doPeek);

    function doCancel(){
      chatCfg.pending = false;
      chatCfg.history = [];
      m.request({method: 'POST', url: g_application_path + "/rest/chat/clear", withCredentials: true, body: {assist:inst.api.assist(), systemCharacter: inst.api.system(), userCharacter: inst.api.user(), rating: inst.api.rating(), uid: page.uid()}}).then((r)=> {
        m.redraw();
      });
    }
    function doChat(){
      if(chatCfg.pending){
        return;
      }
      let msg = document.querySelector("[name='chatmessage']").value; ///e?.target?.value;
      if(msg && msg.length){
        if(!chatCfg.peek){
          doPeek().then(()=>{
            doChat();
          })
        }
        else{
          pushHistory();
          chatCfg.pending = true;
          m.request({method: 'POST', url: g_application_path + "/rest/chat/text", withCredentials: true, body: {assist:inst.api.assist(), systemCharacter: inst.api.system(), userCharacter: inst.api.user(), rating: inst.api.rating(), uid: page.uid(), message: msg}}).then((r)=> {
            if(!chatCfg.history) chatCfg.history = {};
            console.log(r);
            chatCfg.history.messages = r?.messages || [];
            chatCfg.pending = false;
          });
        }
      }
    }
    function pushHistory(){
      let msg = document.querySelector("[name='chatmessage']").value;
      if(!chatCfg.history) chatCfg.history = {};
      if(!chatCfg.history.messages) chatCfg.history.messages = [];
      chatCfg.history.messages.push({role: "user", content: msg});
      document.querySelector("[name='chatmessage']").value = "";
      m.redraw();
    }
    function getHistory(){
      return m.request({method: 'POST', url:g_application_path + "/rest/chat/history", withCredentials: true, body: {assist: inst.api.assist(), systemCharacter: chatCfg.system.firstName, userCharacter: chatCfg.user.firstName, uid: page.uid()}});
    }
    
    function doPeek(){
      chatCfg.history = undefined;
      chatCfg.system = undefined;
      chatCfg.user = undefined;
      chatCfg.peek = false;
      let c1 = inst.api.system();
      let c2 = inst.api.user();
      let p;
      if(c1.length && c2.length){
        p = new Promise((res, rej)=>{
          m.request({method: 'GET', url: g_application_path + "/rest/chat/character/" + c1, withCredentials: true})
          .then((c)=>{
            chatCfg.system = c;
            m.request({method: 'GET', url: g_application_path + "/rest/chat/character/" + c2, withCredentials: true}).then((c2)=>{
              chatCfg.user = c2;
              getHistory().then((h) => {
                chatCfg.peek = true;
                chatCfg.history = h;
                m.redraw();
                res();
              });
            });
          });
        });
        /*
        p = Promise.all([
          m.request({method: 'GET', url: g_application_path + "/rest/chat/character/" + c1, withCredentials: true}).then((c)=>{chatCfg.system = c}),
          m.request({method: 'GET', url: g_application_path + "/rest/chat/character/" + c2, withCredentials: true}).then((c)=>{chatCfg.user = c})
        ]).then(()=>{
          chatCfg.peek = true;
          m.redraw();
        });
        */
      }
      return p;
    }
        function getChatTopMenuView(){

         return [];
        }

        function getSplitContainerView(){
          let splitLeft = "";
          if(!fullMode) splitLeft = getSplitLeftContainerView();
          return m("div", {class: "results-fixed", onselectstart: function(e){ e.preventDefault();}},
            m("div", {class: "splitcontainer"}, [
              splitLeft,
              getSplitRightContainerView()
            ])
          );
        }

        function getSplitRightContainerView(){
          let cls = "splitrightcontainer";
          if(fullMode) cls = "splitfullcontainer";
          return m("div", {class: cls}, [
              getResultsView()     
          ]);
        }

        chat.callback = function(){

        };

        function getSplitLeftContainerView(){

          return m("div", {
            class: "splitleftcontainer",
            ondragover: function(e){
              e.preventDefault();
            }
          }, [
            am7view.form(inst)
          ]);
        }
        function getResultsView(){
          let c1g = "man";
          let c1l = "Nobody";
          let c2g = "man";
          let c2l = "Nobody";
          if(chatCfg.system){
            c1l = chatCfg.system.name;
            if(chatCfg.system.gender == "female"){
              c1g = "woman";
            }
          }
          if(chatCfg.user){
            c2l = chatCfg.user.name;
            if(chatCfg.user.gender == "female"){
              c2g = "woman";
            }
          }

          let msgs = (chatCfg?.history?.messages || []).map((msg) => {
            let align = "justify-start";
            let txt = "bg-violet-400 text-white";
            console.log(msg);
            if(msg.role == "user"){
              align = "justify-end";
              txt = "bg-violet-200 text-slate-500";
            }
            return  m("div", {class: "relative receive-chat flex " + align},
              m("div", {class: "px-5 mb-2 " + txt + " py-2 text-base max-w-[80%] border rounded-md font-light"},
                //m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
                m("p", msg.content)
              )
            );
          });
          let flds = [ m("div", {class: "flex justify-between"}, [
            m("div", {class: "flex items-center"}, [
              m("span", {class: "material-icons-outlined"}, c1g),
              m("span", {class: "text-gray-400 text-base pl-4"}, c1l)
            ]),
            m("div",{class: "flex items-center"}, [
              
              m("span", {class: "text-gray-400 text-base pl-4"}, c2l),
              m("span", {class: "material-icons-outlined"}, c2g)
              //m("i", {class: "material-icons text-violet-300"}, "chat")
            ])
          ])
        ];
        flds.push(...msgs);
          let ret = m("div", {class: "h-full overflow-y-auto"}, [
            m("div", {class: "bg-white user-info-header px-5 py-3"},
             flds
            /*
            m("div", {class: "relative receive-chat flex justify-start"},
              m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
                m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
                m("p", "Here is the text")
              )
            ),
            m("div", {class: "relative receive-chat flex justify-end"},
              m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
              m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
                m("p", "Here is the text")
              )
            ),
            m("div", {class: "relative receive-chat flex justify-start"},
            m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
              m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
              m("p", "Here is the text")
            )
          ),
          m("div", {class: "relative receive-chat flex justify-end"},
            m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
            m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
              m("p", "Here is the text")
            )
          ),
          m("div", {class: "relative receive-chat flex justify-start"},
          m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
            m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
            m("p", "Here is the text")
          )
        ),
        m("div", {class: "relative receive-chat flex justify-end"},
          m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
          m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
            m("p", "Here is the text")
          )
        ),
        m("div", {class: "relative receive-chat flex justify-start"},
        m("div", {class: "px-5 mb-2 bg-violet-400 text-white py-2 text-sm max-w-[80%] rounded font-light"},
          m("i", {class: "material-icons text-violet-400 -top-4 absolute"}, "arrow_upward_alt"),
          m("p", "Here is the text")
        )
      ),
      m("div", {class: "relative receive-chat flex justify-end"},
        m("div", {class: "px-5 mb-2 bg-violet-200 text-slate-500 py-2 text-sm max-w-[80%] rounded font-light"},
        m("i", {class: "material-icons text-violet-200 -bottom-2 right-0 absolute"}, "arrow_downward_alt"),
          m("p", "Here is the text")
        )
      )
      */
            /*
            ,
            m("div", {class: "bg-gray-100 fixed bottom-0 w-full pl-4"},
              m("textarea", {class: "w-full bg-gray-100 pt-3 h-12 focus:outline-none font-light", placeholder: "Message"})
            )
            */
)]);
          /*
          <div class="">


          
        <div class="bg-gray-100 fixed bottom-0 w-full pl-4">
          <textarea class="w-full bg-gray-100 pt-3 h-12 focus:outline-none font-light" placeholder="Write a message"></textarea>
        </div> <!-- Footer message -->
      </div>
    </div>

          */
          //let mtx = treeView.selectedNode();
          //if(!mtx) return ret;
           // return m("div", {}, "Chat View");
           return ret;
        }

        function getChatBottomMenuView(){
          // if(!showFooter) return "";
          return m("div", {class: "result-nav-outer"}, 
            m("div", {class: "results-fixed"},
            m("div", {class: "splitcontainer"}, [
              m("div", {class: "splitleftcontainer"}, "..."),
              m("div", {class: "splitrightcontainer result-nav-inner"},

                m("div",{class: "tab-container result-nav w-full"},[
                m("button", {class: "button", onclick: doCancel},m("span", {class: "material-symbols-outlined material-icons-24"}, "cancel")),
                m("input[" + (chatCfg.pending ? "disabled='true'":"") + "]", {type: "text", name: "chatmessage", class: "text-field w-[80%]", placeholder: "Message", onkeydown : function(e){ if (e.which == 13) doChat(e);}}),
                m("button", {class: "button", onclick: doChat},m("span", {class: "material-symbols-outlined material-icons-24"}, "chat"))
                ])
              )
            ]),
          )
          );
          /*
          return m("div", {class: "result-nav-outer"}, 
            m("div", {class: "result-nav-inner"}, [
              m("div", {class: "result-nav"}, "..."),
              m("div", {class: "result-nav"}, "Bottom")
            ])
          );
          */
        }
      
        function getChatView(vnode){
            return m("div",{class : "content-outer"},[
              (fullMode ? "" : m(page.components.navigation, {hideBreadcrumb: true})),
              m("div",{class : "content-main"},
                m("div", {class: "list-results-container"},
                  m("div", {class: "list-results"}, [
                    getChatTopMenuView(),
                    getSplitContainerView(),
                    getChatBottomMenuView()
                  ])
                )
              )
            ]);
        }
        chat.toggleFullMode = function(){
          fullMode = !fullMode;
          m.redraw();
        }
        chat.cancelView = function(){
          altView = undefined;
          fullMode = false;
          m.redraw();
        };
        chat.editItem = function(object){
          if(!object) return;
          console.log("Edit", object);
          altView = {
            fullMode,
            view: page.views.object(),
            type: object.model,
            containerId: object.objectId
          };
          m.redraw();
        };
        chat.addNew = function(type, containerId, parentNew){
          altView = {
            fullMode,
            view: page.views.object(),
            type,
            containerId,
            parentNew,
            new: true
          };
          m.redraw();
        };
        chat.view = {
            oninit : function(vnode){
                let ctx = page.user.homeDirectory;
                origin = vnode.attrs.origin || ctx;
            },
            oncreate : function (x) {
              // app = page.space(entityName, x, pagination.entity);
            },
            onupdate : function(x){

            },
            onremove : function(x){
              // document.documentElement.removeEventListener("keydown", navListKey);
              page.navigable.cleanupContextMenus();
              pagination.stop();
              // if(app) app.destroy();
            },
  
            view: function (vnode) {
              let v = getChatView(vnode);
                return [v, page.loadDialog()];
            }
        };
        return chat;
    }
      page.views.chat = newChatControl;
  }());
  