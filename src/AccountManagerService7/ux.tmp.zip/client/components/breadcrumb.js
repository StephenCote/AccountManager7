(function(){
    const breadCrumb = {};
    let space;
    let vnode;
    let entityName = "sig";
    let app;
    let udef;
    let requesting = false;
    let forced = false;
    /*
    let model = {
        lifecycles : {
            list : udef
        },
        projects : {},
        contextObjects : {}
    };
    */

    function toggleCommunity(bForce){

        if(bForce && forced) return;
        else if(bForce) forced = true;
        AM7Client.isCommunityConfigured(function(b){
            if(!b){
                if(page.application.userRoles.filter(r => r.name.match(/^systemadministrators$/gi)).length){
                    if(confirm("Organization " + AM7Client.currentOrganization + " is not configured for community mode.  Configure it now?")){
                        AM7Client.configureCommunity(function(s,v){
                            if(v && v.json) toggleCommunity();
                            else alert("Unable to configure community");
                        });
                    }
                }
                else{
                    alert("Organization " + AM7Client.currentOrganization + " is not configured for community mode.  Contact the system administrator for this organization to configure it.");
                }
            }
            else{
                let cid = m.route.param("communityId");
                am7community.setCommunityMode(!am7community.getCommunityMode());
                if(cid && !am7community.getCommunityMode()){
                    m.route.set("/main");
                }
                else{
                    if(cid) selectLifecycle();
                    m.redraw();
                }
            }
        });
    }
    function selectLifecycle(){
        let comSel = document.querySelector("#selCommunityList").value;
        if(comSel && comSel != "0"){
            let cid = m.route.param("communityId");
            if(cid && cid == comSel){
                // console.log("SELECT COMMUNITY: " + cid);
                AM7Client.get("LIFECYCLE",comSel,function(s,v){
                    if(v && v.json) v = v.json;
                    am7community.setCommunityLifecycle(v, true).then(()=>{
                        m.route.set(page.getRawUrl());
                        //m.redraw();
                    });
                });
            }
            else{
                // console.log("ROUTE COMMUNITY: " + cid);
                //m.route.set("/community/" + comSel, {key: comSel});
                m.route.set("/community/" + comSel);
            }
        }
    }
    function selectProject(){
        
        let proSel = document.querySelector("#selProjectList").value;
        if(proSel && proSel != "0"
            && (am7community.getCommunityProject() == null || am7community.getCommunityProject().objectId != proSel)
        ){
            let cid = m.route.param("communityId");
            let pid = m.route.param("projectId");
            if(pid && pid == proSel){
                AM7Client.get("PROJECT",proSel,function(s,v){
                    if(v && v.json) v = v.json;
                    am7community.setCommunityProject(v, false, true).then(()=>{
                        m.route.set(page.getRawUrl(), {key: Date.now()});
                        //m.redraw();
                    });
                });
            }
            else{
                //m.route.set("/community/" + cid + "/" + proSel, {key: proSel});
                m.route.set("/community/" + cid + "/" + proSel, {key: Date.now()});
            }
        }
    }
    function buildProjectList(){
        let bMode = am7community.getCommunityMode();
        let lc = am7community.getCommunityLifecycle();
        let model = page.context();
        if(!lc || lc == null || !bMode || !model.projects[lc.objectId] || !model.projects[lc.objectId].list.length) return m("option",{value:"0"},"[ Project List ]");
        return model.projects[lc.objectId].list.map((v)=>m("option",{value:v.objectId},v.name));
    }

    function buildCommunityList(){
        let bMode = 0; //am7community.getCommunityMode();
        let model = page.context();
        if(!bMode || !model.lifecycles.list || !model.lifecycles.list.length) return m("option",{value:"0"},"[ Community List ]");
        let cid = m.route.param("communityId");
        let udef;
        return model.lifecycles.list.map((v)=>m("option",{selected : (cid && cid == v.objectId ? true : udef), value:v.objectId},v.name));
    }

    function refreshCommunity(){
        if(requesting || !page.authenticated()) return;
        let cid = m.route.param("communityId");
        let bMode = 0; //am7community.getCommunityMode();
        let model = page.context();
        /*
        Hemi.xml.setInnerXHTML(document.querySelector("#icoCommunityMode"), (bMode ? "group" : "group_off"));
        let comSel = document.querySelector("#selCommunityList");
        let proSel = document.querySelector("#selProjectList");
        comSel.style.display = (bMode ? "" : "none");
        proSel.style.display = (bMode ? "" : "none");
        
        if(bMode){
            let lc = am7community.getCommunityLifecycle();
            let lp = am7community.getCommunityProject();

            if(!model.lifecycles.list){
                // console.log("List communities");
                requesting = true;
                am7community.listLifecycles().then((aL)=>{
                    model.lifecycles.list = aL;
                    requesting = false;
                    m.redraw();
                });
            }
            else if(lc && lc != null && !model.projects[lc.objectId]){
                // console.log("List projects");
                requesting = true;
                am7community.listProjects().then((aP)=>{
                    // console.log("Received " + aP.length);
                    model.projects[lc.objectId] = {list:aP};
                    requesting = false;
                    m.redraw();
                });
            }
            else{
                if(!lc || lc == null){

                    let lid = comSel.value;
                   
                    if(lid && lid != "0"){
                        // console.log("Set lifecycle");
                        selectLifecycle();
                    }
                }
                else{
                    if(!lp || lp == null){
                        let pid = proSel.value;
                        if(pid && pid != "0"){
                            // console.log("Set project "+ pid);
                            selectProject();
                        }
                        else{
                            console.log("Don't select proj: " + pid);
                        }
                    }
                }
            }
        }
        */

    }
    function communityButton(){
        return m("button",{id: "btnCommunityMode", class: "page-button", onclick : toggleCommunity}, m("span", {id: "icoCommunityMode", class: "material-symbols-outlined material-icons-cm"},"group_off"));
    }
    function modelCommunityCrumb(){
        return [
            m("select", {id: "selCommunityList", onchange: selectLifecycle, class: "page-select reactive-arrow"},
                buildCommunityList()
            ),
            m("select", {id: "selProjectList", onchange: selectProject, class: "page-select reactive-arrow"},
                buildProjectList()
            )
        ]
        ;
    }

    let crumbButtons;
    function modelBreadCrumb(){
        let oL = document.querySelector("#listBreadcrumb");
        let sPath = page.user.homeDirectory.path;
        let model = page.context();
        /*
        if(am7community.getCommunityMode()){
            sPath = am7community.getPaths().project;
            if(am7community.getCommunityProject()) sPath += "/" + am7community.getCommunityProject().name;
        }
        */
        let objectId;
        let modType;
        let type = m.route.param("type") || "data.data";
        if(type){
            modType = am7model.getModel(type);
            type = modType.type || type;
        }

        /// TOOD: Fix bug where creating a new type of group and parent (eg: a note) inside a parent, the context needs to be the parent, not the group
        /// - fix by using /pnew to force use of parent

        let objType = type;
        if(m.route.get().match(/\/(list|new)\//gi)){
            objType = "auth.group";
        }
        
        if(modType && am7model.inherits(modType, "data.directory") && (objectId = m.route.param("objectId")) != null){
            let typeUdef = typeof model.contextObjects[objectId] == "undefined";
            /// was typeUdef && 
            if(typeUdef || model.contextObjects[objectId] == null){
                model.contextObjects[objectId] = null;
                //requesting = true;
                console.log("Breadcrumb Get: " + objType + "::" + objectId);
                AM7Client.get(objType, objectId, function(v){
                    model.contextObjects[objectId] = v;
                    //requesting = false;
                    m.redraw();
                });
                //return;
            }
            else if(!typeUdef && model.contextObjects[objectId] != null){
                //console.log("Getting context path", objType, model.contextObjects[objectId]);
                sPath = model.contextObjects[objectId][(objType.match(/^auth\.group/gi) ? "path" : "groupPath")];
            }
        }
        //console.log(m.route.get() + " -" + objectId + " : " + type + " : " + objType + " : " + sPath + " / " + requesting);
        //if(requesting) return;
        let aSp = sPath.split("/").slice(1);
        let bBack = [];
        let crumbs = [];
        crumbButtons = [];
        aSp.forEach((p)=>{
            bBack.push("/" + p);
            // !am7community.getCommunityMode() || 
            if(!p.match(/(rocket|lifecycles|projects)/gi)){
                let bJoi = bBack.join("");
                let id = bJoi.replace(/\//g,"zZz").replace(/\s/g,"yYy");
                let bid = id + "Button";
                let handler;
                let menuCls = "context-menu-container-slim";
                let btnCls = "multi-button";
                let disabled = false;
                if((bJoi.match(/^\/home$/gi) || bJoi.match(/^\/$/)) && !page.context().roles.admin){
                    menuCls += " context-menu-container-disabled";
                    btnCls = "multi-button-disabled";
                    disabled = true;
                }
                else{
                   handler = function(){page.navigateToPath(type, modType, bJoi).then((id)=>{ page.listByType(type, id); });}
                }


                if(!disabled) crumbButtons.push({id:id,bid:bid,path:bJoi,items:[]});
                crumbs.push(m("li","/"));
                crumbs.push(m("li",[
                    m("div",{class : menuCls},[
                        m("button" + (disabled ? "[disabled = 'true']" : ""),{onclick : handler, class : "rounded-l " + btnCls}, p),
                        (!disabled ? m("button",{id : bid, class : "rounded-r " + btnCls}, m("span",{class : "material-symbols-outlined material-icons-cm"}, "expand_more")) : ""),
                        (!disabled ? m("div", {id : id, class : "transition transition-0 context-menu-48"}, [
                            page.navigable.contextMenuButton(id,"Loading","folder_off"),
                        ]) : "")
                    ])

                ]));
            }
        });
        return crumbs;
    }
  


    function buildBreadCrumb(){
        let type = m.route.param("type") || "data.data";
        let modType = am7model.getModel(type);

        return m("nav",{class: "breadcrumb-bar"},[
            m("div", {class: "breadcrumb-container"}, [
                m("nav",{class: "breadcrumb"}, [
                    m("ol", {id: "listBreadcrumb", class: "breadcrumb-list"},[
                        m("li",m("span", {class: "material-symbols-outlined material-icons-24"}, modType.icon)),
                        /*
                        m("li",[
                            modelCommunityCrumb()
                        ]),
                        */
                        modelBreadCrumb()
                    ])
                ])
            ])
        ]);

    }

    function contextMenuItemHandler(query, object){
        let aP = query.items.filter((i)=>{
            if(object.path == i.path) return true;
        });

        let type = 'data';
        let modType = am7community.getTypeByPath(object.name);
        if(modType) type = modType;
                    
        if(aP.length){
            page.listByType(type, aP[0].objectId);
        }
    }

    function configureContextMenus(){
        crumbButtons.forEach((v)=>{
            page.navigable.addContextMenu("#" + v.id,"#" + v.bid,{
                menu : v.id,
                action : "list",
                type : "auth.group",
                subType : "data",
                objectId : 0,
                path : v.path,
                handler : contextMenuItemHandler,
                icon : "folder"
            });
        });
    }
    function cleanupContextMenus(){
        crumbButtons.forEach((v)=>page.navigable.removeContextMenu("#" + v.id));
    }
    function setupDisplayState(){
        let cid = m.route.param("communityId");
        if(cid){
            if(!am7community.getCommunityMode()){
                toggleCommunity(true);
                return;
            }
            else if(am7community.getCommunityLifecycle() && am7community.getCommunityLifecycle().objectId != cid){
                selectLifecycle();
                return;
            }
        }
        refreshCommunity();
        configureContextMenus();
    }
    breadCrumb.component = {
        toggleCommunity : toggleCommunity,

        oninit : function(x){

        },
        onupdate : function(){
            cleanupContextMenus();
            setupDisplayState();
        },
        oncreate : function (x) {
            setupDisplayState();

        },
        onremove : function(x){
            cleanupContextMenus();
        },

        view: function () {
            //console.log("Render breadcrumb");
            return m("div", { avoid : "1", class : ""},
                buildBreadCrumb()
            );
         }
    };

    page.components.breadCrumb = breadCrumb.component;
}());
