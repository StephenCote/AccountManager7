(function(){

    const dnd = {
        dragTarget: undefined,
        overTarget: undefined,
        workingSet: []
    };
    dnd.doBlend = async function(sId){
        let blended = [];
        let blender = [];
        //console.log("Blend", sId);
        dnd.workingSet.forEach((w)=>{
            /// if an id is specified, then that is the item to apply to the rest of the set
            /// if an id isn't specified, then the blender list will be any tag, event, group, or role
            if((sId && w.objectId == sId) || (!sId && w.model.match(/^(data\.tag|olio\.event|auth\.group|auth\.role)$/gi) && (!w.model.match(/^auth\.group$/gi) || w.type.match(/^(person|account|bucket)$/gi)))){
                blender.push(w);
            }
            else{
                blended.push(w);
            }
        });
        let aP = [];
        let filt = {};
        blender.forEach((b)=>{
            blended.forEach((b2)=>{
                let actor = b2.model.match(/^account|person|user$/gi);
                
                switch(b.model){
                    case "auth.role":
                        if(actor && b.type == b2.model){
                            aP.push(page.member(b.model, b.objectId, b2.model, b2.objectId, true));
                            filt[b2.objectId]=true;
                        }
                        else{
                            console.warn("Skip actor type: " + b2.model + " for role " + b.type);
                        }
                        break;
                    case "auth.group":
                        if((actor && b2.model == b.type)|| (b.type == "bucket" && b2.model == "data.data")){
                            aP.push(page.member(b.model, b.objectId, b2.model, b2.objectId, true));
                            filt[b2.objectId]=true;
                        }
                        else{
                            console.warn("Skip actor type: " + b2.model + " for group " + b.type);
                        }
                        break;
                    case "data.tag":
                        if((actor || b2.model.match(/^data$/gi)) && b2.model == b.tagType){
                            aP.push(page.tag(b2, b, true));
                            filt[b2.objectId]=true;
                        }
                        else{
                            console.warn("Skip object type: " + b2.model + " for tag type " + b.tagType);
                        }
                        break;
                    /// Need to populate these in order to obtain contactInformation
                    case "system.user":
                    case "identity.account":
                    case "identity.person":
                        let bUp = false;
                        console.log(b, b2);
                        if(b2.model.match(/^contact$/gi)){
                            b.contactInformation.contacts.push(b2);
                            bUp = true;
                        }
                        if(b2.model.match(/^address$/gi)){
                            b.contactInformation.addresses.push(b2);
                            bUp = true;
                        }
                        if(bUp){
                            aP.push(page.updateObject(b));
                        }

                        console.log("Blend " + b.model + " with " + b2.model);
                        break;
                    default:
                        console.warn("Unhandled", b.model);
                        break;
                        
                }
            });


        });
        await Promise.all(aP);
        dnd.workingSet = dnd.workingSet.filter((o)=> !filt[o.objectId]);
 
        console.log("Blended", blender);

    };
    dnd.doDragDecorate = function(object){
        let cls;
        if(!object || !object.objectId) return cls;
        if(dnd.dragTarget && dnd.dragTarget.objectId == object.objectId){
        cls = "hover:bg-orange-200";
        }
        else if(dnd.overTarget && dnd.overTarget.objectId == object.objectId && dnd.dragTarget.objectId != object.objectId){
        let modType = am7model.getModel(object.model.toLowerCase());
        if(dnd.overTarget.model.match(/^auth\.group$/gi) || am7model.inherits(modType, "common.parent")){
            cls = "hover:bg-green-200 bg-green-200";
        }
        }
        return cls;
    }

    dnd.doDragStart = function(e, obj){
        //console.log("Drag start", obj.name);
        e.dataTransfer.setData('text', obj.objectId);
        dnd.dragTarget = obj;
        //m.redraw();
    }
    dnd.doDragOver = function(e, obj){
        if(obj && dnd.dragTarget){

        if(typeof obj === "string"){
            dnd.overTarget = obj;
        }
        if(obj.objectId != dnd.dragTarget.objectId){
            dnd.overTarget = obj;
        }
        }
    }
    dnd.doDragEnd = function(e, obj){
        dnd.dragTarget = undefined;
        dnd.overTarget = undefined;
    }
    dnd.doDrop = async function(e, obj){
        let ret = false;
        if(obj && dnd.dragTarget){
            let dragGroup = dnd.dragTarget.model.match(/^auth\.group$/gi);
            let dragModType = am7model.getModel(dnd.dragTarget.model.toLowerCase());
            if(typeof obj === "string"){
                if(obj === "set"){
                    let aL = dnd.workingSet.filter((o)=>{ if(o.objectId == dnd.dragTarget.objectId) return true; });
                    if(aL.length){
                        console.warn("Already in set");
                    }
                    else{
                        // console.log("Working with " + dnd.dragTarget);
                        dnd.workingSet.push(dnd.dragTarget);
                        ret = true;
                    }
                }
            }  
            else if(dnd.overTarget){
                let dropGroup = dnd.overTarget.model.match(/^auth\.group$/gi);
                
                //let dropModType = am7model.getModel(dnd.overTarget.model.toLowerCase());
                if(dragGroup && dropGroup){
                    ret = await page.reparentObject(dnd.dragTarget, dnd.overTarget);
                }
                /// am7model.inherits(dragModType, "data.directory")
                else if(dropGroup && am7model.isGroup(dragModType)){
                    ret = await page.moveObject(dnd.dragTarget, dnd.overTarget);
                }
                else{
                    console.warn("Don't know what to do: Drop: " + dnd.dragTarget.name + " on " + dnd.overTarget.name);
                }
            }
        }
        return ret;

    }
/*
    let dndProps = {
        dragDecorator: doDragDecorate,
        dragStartHandler: doDragStart,
        dragOverHandler: doDragOver,
        dragEndHandler: doDragEnd,
        dropHandler: doDrop
    };
*/
    /*
    function shuffleTrayXXX(){
        //console.log("Shuffle tray");
        let dndProps = {

        }
        let buttons = workingSet.map((o)=>{
        let modType = am7model.getModel(o.model.toLowerCase());
        let icon = "device_unknown";
        if(modType.icon){
            icon = modType.icon;
        }
        return page.components.topMenu.menuButton(o.name, icon);
        });
        return m("div[draggable]", {
        class : "w-96 place-content-end border rounded-lg border-orange-600 menu-buttons",
        //ondragover: function(e) { doDragOver(e, "shuffle");},
        ondragover: function(e){
            e.preventDefault();
        },
        ondrop: function(){ doDrop(e, "shuffle");}
        },[
        buttons,
        page.components.topMenu.menuButton(0, "backspace", "", function(){
            workingSet.length = 0;
            m.redraw();
        })
        ]);
    }
    */

      page.components.dnd = dnd;
  }());
  