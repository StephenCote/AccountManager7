(function(){
    	/// Community mode uses the Rocket organized structure instead of the user's home folder for storing data
	///
	var communityMode = false;
    
    let subType = [
		"DWAC","Address","Contact","Application","Group","Ticket","Story","Requirement","Note","Module","Model","Goal","ValidationRule","Form","FormElement","Case","Artifact","ProcessStep","Process","Method","Stage","Data","Work","Task","Cost","Time","Estimate","Budget","Person","Account","Resource","Lifecycle","Project","Schedule","Methodology","Policy","Pattern","Rule","Fact","Operation","Function","Permission","Role","Tag","Event","Location","Trait"
	];

	/// LifecycleScope, in community mode, means everything is shared between projects at the lifecycle level
	///
	var lifecycleScope = false;
	
	var autoCreate = false;
	var autoRead = false;
	var contextLifecycle = 0;
	var contextLifecycleGroup = 0;
	var contextProject = 0;
	var contextProjectGroup = 0;
	var dayInMs = (24 * 60 * 60 * 1000);
	/// placeholder for non-community reference
	var currentProject = 0;
	var currentRoleBucket = 0;
	var currentPermissionBucket = 0;
    let paths = {};
    let cache = {
        projects : {}
    };

	/// 
	function updateBase(){
		//communityMode = (b ? true : false);

		paths.basePath = (communityMode ? "/Rocket" : "~");
		//paths.lifecyclePath = paths.basePath + "/Lifecycles";

		if(communityMode && contextLifecycleGroup){
			paths.basePath = contextLifecycleGroup.path;
            //if(paths.basePath.match(/^\/home/gi)) paths.basePath += "/" + contextLifecycle.name;
			//paths.projectPath = paths.basePath + "/Projects";
			if(!lifecycleScope && contextProjectGroup){
				paths.basePath = contextProjectGroup.path;
                if(paths.basePath.match(/^\/home/gi)) paths.basePath += "/" + contextProject.name;
			}
		}
		else{
			//paths.project = paths.basePath + "/Projects";
		}
        //console.log("Update base: " + paths.basePath);
        subType.forEach((i)=>{
            let type = i.toLowerCase();
            if(type.match(/^(permission|role)$/)){
                paths[type] = paths.basePath;
            }
            else if(type.match(/^(data|work|dwac)$/)){
                paths[type] = paths.basePath + "/" + i;
            }
            else if(type.match(/y$/)){
                paths[type] = paths.basePath + "/" + i.replace(/y$/,"ies");
            }
            else if(type.match(/s$/)){
                paths[type] = paths.basePath + "/" + i + "es";
            }
            else{
                paths[type] = paths.basePath + "/" + i + "s";
            }

        });
	}

	function getDefaultParentByType(s,d){
        return new Promise((res, rej)=>{
            if(!communityMode || !contextProject){
                res(d);
            }
            else{
                let o = d;
                switch(s.toLowerCase()){
                    case "permission":
                        AM6Client.communityProjectPermissionBase(contextProject, function(s, v){
                            if(v && v.json) v = v.json;
                            res(v);
                        });
                        break;
                    case "role":
                        AM6Client.communityProjectRoleBase(contextProject, function(s, v){
                            if(v && v.json) v = v.json;
                            res(v);
                        });
                        break;
                    default:
                        res(o);
                        break;
                }
            }
        });
	}
	function getBasePathByType(s){
        if(!s) return paths.basePath;
        return paths[s.toLowerCase()];
	}
	function getTypeByPath(sPath){
        let subPath = sPath.substring(sPath.lastIndexOf("/") + 1);
        let outT;
        let aP = Object.keys(paths).filter((k)=>{if(paths[k].substring(paths[k].lastIndexOf("/") + 1) == subPath) return true;});
        if(aP.length) outT = aP[0];
        if(!outT){
            let outP = am7model.getPrototype(subPath.toLowerCase());
            if(outP) outT = outP.key;
            //console.log(outP, outT);
        }
        return outT;
    }

     function getPathForType(type){

        let typeModel = am7model.getModel(type);
        if(typeModel == null) return null;

        let path = null;
 
        if(typeModel.pathName) path = am7community.getBasePath() + "/" + typeModel.pathName;
        else path = am7community.getBasePath(type);
        /// objects with no group or parent-only (which is distinct in the model from group based) won't have a path, such as users, roles, permissions,
        if(path != null) path = path.replace(/^~/, page.user.homeDirectory.path);
        return path;
    }

    let am7community = Hemi.newObject("AM6 Community Interface","1.0",true,true,{
        object_create : function(){
            updateBase();
        },
        getCommunityMode : function(){ return communityMode;},
        getPathForType : getPathForType,
        getPaths : function(){return paths},
        getBasePath : getBasePathByType,
        getTypeByPath : getTypeByPath,
        getParentByType : getDefaultParentByType,
        /// getGroup : function(s){ return AM6Client.find("group","data",am7community.getBasePath(s));},

        setCommunityProject : function(p, c, b){
            currentProject = 0;
            contextProject = (p ? p : 0);
            contextProjectGroup = 0;
            let prom = [];
            if(contextProject) prom.push(new Promise((res,rej)=>{
                AM6Client.get("group",contextProject.groupId, function(s,v){
                    if(v && v.json) v = v.json;
                    contextProjectGroup = v;
                    res();
                });
            }));
            (contextProject ? 
                prom.push(new Promise((res,rej)=>{
                    AM6Client.communityProjectRoleBase(contextProject, function(s,v){
                        if(v && v.json) v = v.json;
                        currentRoleBucket = v;
                        res();
                    }) ;
                }))
                : 0
            );
 
            (contextProject ? 
                prom.push(new Promise((res,rej)=>{
                    AM6Client.communityProjectPermissionBase(contextProject, function(s,v){
                        if(v && v.json) v = v.json;
                        currentPermissionBucket = v;
                        res();
                    }); 
                }))
                : 0
            );
            return Promise.all(prom).then(()=>{
                lifecycleScope = (c ? true : false);
                updateBase();
                if(!b) Hemi.message.service.publish("onchangecommunity", this);
            });
        },
        setCommunityMode : function(b, v){
            communityMode = (b ? true : false);
            updateBase();
            if(!v) Hemi.message.service.publish("onchangecommunity", this);
        },
        setCurrentProject : function(o){
            if(communityMode) return;
            contextProject = 0;
            contextProjectGroup = 0;
            currentProject = (o ? o : 0);
        },
        getCurrentProject : function(){
            if(communityMode) return;
            return currentProject;
        },
        setCommunityLifecycle : function(l, b){
            return new Promise((res,rej)=>{
                if(!communityMode) communityMode = (l ? true : false);
                contextLifecycle = (l ? l : 0);
                contextLifecycleGroup = 0;
                contextProject = 0;
                contextProjectGroup = 0;
                lifecycleScope = true;
                if(contextLifecycle){
                    AM6Client.get("group",contextLifecycle.groupId, function(s,v){
                        if(v && v.json) v = v.json;
                        contextLifecycleGroup = v;
                        res();
                    });
                }
                else res();

            }).then(()=>{
                updateBase();
                if(!b) Hemi.message.service.publish("onchangecommunity", this);
            });
        },
        getCommunityLifecycle : function(){return contextLifecycle;},
        getCommunityProject : function(){return contextProject;},
        getCommunityProjectGroup: function(){
            return contextProjectGroup;
        },
        getCommunityLifecycleGroup: function(){
            return contextLifecycleGroup;
        },
        listLifecycles : function(sFilter){
            
            return (cache.lifecycles && cache.lifecycleFilter == sFilter ? Promise.resolve(cache.lifecycles) : new Promise((res,rej) => {
                cache.lifecycleFilter = sFilter;
                cache.lifecycles = [];
                AM6Client.find("group","data",(communityMode ? '/Rocket/Lifecycles' : paths.lifecycle), function(s, v){
                    if(v && v.json) v = v.json;
                    let oG = v;
                    if(!oG || oG == null){
                        console.error("Null group");
                        res([]);
                    }
                    else{
                        if(!communityMode){
                            AM6Client.list("LIFECYCLE", oG.objectId, 0, 0, function(t,w){
                                if(w && w.json){
                                    cache.lifecycles = w.json;
                                    res(w.json);
                                }
                            });
                        }
                        else{
                            let lifList = [];
                            let vFilter = [];
                            if(sFilter) vFilter.push(AM6Client.newFieldMatch("TEXT","NAME","LIKE","*" + sFilter + "*"));
                            var oS = AM6Client.newSortQuery("NAME","ASCENDING");
                            var oReq = AM6Client.newSearchRequest('LIFECYCLE',0,0,0,10,false,oS,vFilter);
                            oReq.distinct = true;
                            oReq.groupScope = oG.objectId;
                            AM6Client.search(oReq,function(s,v){
                                if(v && v.json){
                                    cache.lifecycles = v.json;
                                    res(v.json);
                                }
                                else{
                                    console.error("Invalid response");
                                }
                            });
                        }
                    }
                });
            }));
        },
        listProjects : function(sFilter){
            console.log("List projects: " + paths.project);
            
            if(communityMode && (!contextLifecycle || contextLifecycle == null)){
                console.error("A context lifecycle hasn't been selected");
                return Promise.resolve([]);
            }
            let lid = (communityMode ? contextLifecycle.objectId : 'my');
            return (cache.projects[lid] ? Promise.resolve(cache.projects[lid]) : new Promise((res,rej) => {
                AM6Client.find("group","data",paths.project, function(s, v){
                    let oG = v;
                    if(v && v.json) oG = v.json;
                    if(!oG || oG == null){
                        console.error("Null group");
                        res([]);
                    }

                    else{
                        if(!communityMode){
                            console.log("List local projects");
                            AM6Client.list("PROJECT", oG.objectId, 0, 0, function(t,w){
                                if(w && w.json) w = w.json;
                                cache.projects[lid] = [];
                                res(w);
                            });
                        }
                        else{
                            let lifList = [];
                            let vFilter = [];
                            if(sFilter) vFilter.push(AM6Client.newFieldMatch("TEXT","NAME","LIKE","*" + sFilter + "*"));
                            var oS = AM6Client.newSortQuery("NAME","ASCENDING");
                            var oReq = AM6Client.newSearchRequest('PROJECT',0,0,0,10,false,oS,vFilter);
                            oReq.distinct = true;
                            oReq.groupScope = oG.objectId;
                            console.log("List projects in " + oG.urn);
                            AM6Client.search(oReq,function(s,v){
                                if(v && v.json) v = v.json;
                                cache.projects[lid] = v;
                                res(v);
                                
                            });
                        }
                    }
                });
            }));
        },
 

        /*
        listProjects : function(){
            return new Promise((res, rej)=>{
                if(!communityMode){
                    AM6Client.find("group","data",paths.project, function(s, v){
                        let oG = v.json;
                        if(!oG || oG == null) res([]);
                        else AM6Client.list("PROJECT",oG.objectId,0,0, function(t, w){
                            res(w.json);
                        });
                    });
                }
                else{
                    if(contextLifecycle == null) res([]);
                    AM6Client.find("group","data",contextLifecycle.groupPath + "/Projects", function(s,v){
                        let oG = v.json;
                        if(oG == null) res([]);
                        AM6Client.list("PROJECT",oG.objectId,0,0, function(t, w){
                            res(w.json);
                        });
                    });
                }
            });
            */
            /*
            if(!communityMode){
                var oG = AM6Client.find("group","data",projectPath);
                if(!oG || oG == null) return [];
                return AM6Client.list("PROJECT",oG.objectId,0,0);
            }
            var oL = contextLifecycle;
            if(!oL || oL == null){
                return [];
            }
            var projList = [];
            var a = AM6Client.list("group",AM6Client.find("group","data",oL.groupPath + "/Projects").objectId,0,0);
            for(var i = 0; i < a.length; i++){
                var oP = AM6Client.getByName("PROJECT",a[i].objectId,a[i].name);
                if(oP != null)  projList.push(oP);
            }
            return projList;
            
        }
        */
          /// This snarly promisey beast creates a community and project and populates it with location data.
        countByPath : async function(nameType, path){
            return new Promise((res, rej)=>{
                AM6Client.find("group", "data", path, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    AM6Client.count(nameType, v.objectId, function(s2, v2){
                        if(v2 && typeof v2.json != "undefined") v2 = v2.json;
                        res(v2);
                    });
                });
            });
        },
        findCommunity : async function(sName){
            return new Promise((res, rej) => {
                AM6Client.community(sName, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                });
            });
        },
        configureTraits : async function(communityId){
            return new Promise((res, rej) => {
                AM6Client.configureCommunityTraits(communityId, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                });
            });
        },
        addCommunity : async function(sName){
            return new Promise((res, rej) => {
                AM6Client.addCommunity(sName, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                });
            });
        },
        findCommunityProject : async function(communityName, projectName){
            return new Promise((res, rej) => {
                AM6Client.communityProject(communityName, projectName, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                });
            });
        },
        addCommunityProject : async function(communityId, name){
            return new Promise((res, rej) => {
                AM6Client.addCommunityProject(communityId, name, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                });
            });
        },

        getCreateCommunity : async function(communityName){
            let b = await am7community.findCommunity(communityName);
            if(!b){
                c = await am7community.addCommunity(communityName);
                if(c) b = await am7community.findCommunity(communityName);
            }
            return b;
        },

        getCreateCommunityProject : async function(communityName, projectName){
            let c = await am7community.getCreateCommunity(communityName);
            let p = await am7community.findCommunityProject(communityName, projectName);
            if(!p){
                let b = await am7community.addCommunityProject(c.objectId, projectName);
                p = await am7community.findCommunityProject(communityName, projectName);
            }
            return p;
        },

        configureCountryInfo : async function(communityId){
            return new Promise((res, rej)=>{
                AM6Client.configureCommunityCountryInfo(communityId, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                })
            })
        },

        configureAdmin1Codes : async function(communityId){
            return new Promise((res, rej)=>{
                AM6Client.configureCommunityAdmin1Codes(communityId, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                })
            })
        },

        configureAdmin2Codes : async function(communityId){
            return new Promise((res, rej)=>{
                AM6Client.configureCommunityAdmin2Codes(communityId, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                })
            })
        },

        configureCountryData : async function(communityId, aCountries){
            return new Promise((res, rej)=>{
                AM6Client.configureCommunityCountryData(communityId, aCountries, true, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                })
            })
        },

        generateProjectRegion : async function(communityId, projectId, locationSize, locationSeed){
            return new Promise((res, rej)=>{
                AM6Client.configureCommunityProjectRegion(communityId, projectId, locationSize, locationSeed, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                })
            })
        },

        evolveProjectRegion : async function(communityId, projectId, epochCount){
            return new Promise((res, rej)=>{
                AM6Client.evolveCommunityProjectRegion(communityId, projectId, epochCount, 12, function(s, v){
                    if(v && typeof v.json != "undefined") v = v.json;
                    res(v);
                })
            })
        },
            
        getCreateConfiguredCommunityProject : async function(communityName, projectName, countryData, locationSize, locationSeed, evolutions, callback){
            let community = await am7community.getCreateCommunity(communityName);
            if(!community.attributesPopulated) community = await page.openObject("LIFECYCLE", community.objectId);
            let project = await am7community.getCreateCommunityProject(communityName, projectName);
            if(!AM6Client.getAttribute(community, "location.configured")){
                let ct = await am7community.countByPath("TRAIT", community.groupPath + "/Traits");
                if(!ct){
                    callback("Configure traits");
                    let ctCfg = await am7community.configureTraits(community.objectId);
                }
                let cl = await am7community.countByPath("LOCATION", community.groupPath + "/Locations");
                if(!cl){
                    callback("Configure locations");
                    let clCfg = await am7community.configureCountryInfo(community.objectId);
                }
                let locationGroup = await page.findObject("group", "data", community.groupPath + "/Locations");
                let aL = await page.listObjects("LOCATION", locationGroup.objectId, 0, 3);
                if(aL.length > 0 && !AM6Client.getAttribute(aL[0], "geonameid")){
                    callback("Configure administrative codes 1");
                    let a1Cfg = await am7community.configureAdmin1Codes(community.objectId);
                    callback("Configure administrative codes 2");
                    let a2Cfg = await am7community.configureAdmin2Codes(community.objectId);
                    callback("Configure country data");
                    let cntCfg = await am7community.configureCountryData(community.objectId, countryData);
                    if(cntCfg){
                        callback("Configured");
                        community.attributes.push({"name":"location.configured","values":[true],"dataType":"BOOLEAN"});
                        let comUp = page.updateObject(community);
                    }
                    else{
                        callback("Failed to configure country data");
                    }

                }
            }
            if(project){
                let ce = await am7community.countByPath("EVENT", project.groupPath + "/Events");
                if(ce == 0){
                    callback("Generating project region");
                    let bg = await am7community.generateProjectRegion(community.objectId, project.objectId, locationSize, locationSeed);
                }

                let ev = await am7community.evolveProjectRegion(community.objectId, project.objectId, evolutions);
                callback("Ready");
            }
            return project;
            
            /*

            return new Promise((res2, rej2)=>{
                return new Promise((res,rej)=>{
                    this.getCreateCommunityProject(ctx, communityName, projectName).then((a)=>{
                        let lx = a[0];
                        let p = a[1];
                        /// This lookup vs the find behind the previous call is used to make sure the attributes are populated
                        /// This was an old design choice to allow for the parent object to be passed around easily without having to include all the subordinate objects
                        ///
                        (lx.attributesPopulated ? Promise.resolve(lx) : this.getObject(ctx, "LIFECYCLE",lx.objectId)).then((l)=>{
                            if(!this.getAttribute(l, "location.configured")){
            
                                this.countByPath(ctx, "TRAIT", l.groupPath + "/Traits").then((c)=>{
                                    (c ? Promise.resolve(true) : this.configureTraits(ctx, l.objectId)).then(()=>{
                                        this.find(ctx, "group","data", l.groupPath + "/Locations").then((g)=>{
                                            this.count(ctx, "LOCATION", g.objectId).then((d)=>{
                                                (d ? Promise.resolve(true) : this.configureCountryInfo(ctx, l.objectId)).then((e)=>{
                                                    this.list(ctx, "LOCATION", g.objectId, 0,3).then((aL)=>{
                                                        (this.getAttribute(aL[0],"geonameid") ? Promise.resolve(true) : this.configureAdmin1Codes(ctx, l.objectId)).then(()=>{
                                                            console.log("Configured admin 1 codes");
                                                            this.configureAdmin2Codes(ctx, l.objectId).then(()=>{
                                                                console.log("Configured admin 2 codes");
                                                                this.configureCountryData(ctx, l.objectId, countryData).then((ib)=>{
                                                                    if(ib){
                                                                        console.log("Configured country data");
                                                                        l.attributes.push({"name":"location.configured","values":[true],"dataType":"BOOLEAN"});
                                                                        this.updateObject(ctx, l).then((b)=>{
                                                                            (p.populated ? Promise.resolve(p) : this.getObject(ctx, "PROJECT", p.objectId)).then((p2)=>{
                                                                                res([l, p2]);
                                                                            });
                                                                        });
                                                                    }
                                                                    else{
                                                                        console.log("failed to update country data");
                                                                    }
            
                                                                });
                                                            });
                                                        });
                                                    });
            
                                                });
                                            });
                                        });
                                    });
                                });
                            }
                            else{
                                (p.populated ? Promise.resolve(p) : this.getObject(ctx, "PROJECT", p.objectId)).then((p2)=>{
                                    res([l, p2]);
                                });
                            }
                        })
                    });
            
                }).then((a)=>{
                    let l = a[0];
                    let p = a[1];
                    this.countByPath(ctx, "EVENT",p.groupPath + "/Events").then((i)=>{
                        console.info("events: " + i);
                        (i > 0 ? Promise.resolve(i) : this.generateProjectRegion(ctx, l.objectId, p.objectId, locationSize, locationSeed)).then((b)=>{
                            console.log("Generated project region");
                            this.evolveProjectRegion(ctx, l.objectId, p.objectId, evolutions).then((c)=>{
                                res2([l, p]);
                            });
                        });
                    });

                });
            });
            */
        }
    });
    let test = typeof module;
    if(typeof uwm != "undefined"){
        uwm.pathProvider = getBasePathByType;
        uwm.defaultParentProvider = getDefaultParentByType;
    }
    if (typeof module != "undefined") {
        module.exports = am7community;
    } else {
        window.am7community = am7community;
    }

}());