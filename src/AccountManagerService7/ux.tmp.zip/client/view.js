(function(){


    function getActionView(fld, inst){
        let a = inst.form.commands[fld];
        return m("div",[
            m("button",{
            class : "dialog-button",
            onclick : function(){
                inst.action(a.action);
            }
            },[
                m("span",{
                    class : "material-symbols-outlined material-symbols-outlined-white md-18 mr-4"
                },[a.icon]),
            m("span",{
                class: ""
            },[a.label])                         ,
            ])
        ])
    }

    function getFieldView(fld, inst){
        let f = inst.field(fld);
        return m("div",[
            m("label",{
                class : "block",
                for : fld
            },[
                inst.label(fld)
            ]),
           (f ? getField(fld, inst)  : m("span", {class: "bold"}, "Invalid field: " + fld))
        ]);
    }
    function getField(fld, inst){
        let props = {
            oninput: inst.handleChange(fld),
            placeholder : inst.placeholder(fld),
            name : fld
        };
        let fprops = inst.viewProperties(fld);
        if(fprops){
            props = Object.assign(fprops, props);
        }

        let type = inst.formField(fld, "type") || "text";

        return m("input", Object.assign({
                class : "text-field-full",
                type
            }, props)
        );
    }
    
    function form(inst){

        let vf = inst.form;

        let el = Array.from(Object.entries(vf.fields).map( ([k, f]) => {
            let x = inst.design(k);
            if(!x){
                x = getFieldView(k, inst);
            }
            return [k,x];
        }), ([key, value]) => value);
        let el2 = Array.from(Object.entries(vf.commands).map(([k, c]) => {
            return [k, getActionView(k, inst)];
        }), ([key, value]) => value);
        el.push(...el2);

        let v = [m("h3",{
            class : "box-title"
        },[
            icon(inst),
            label(inst)
        ]),
        m("div",{
                class : "mt-4"
            },
            el
        )
        ];
        return v;
    }

    function icon(v){
        if(v.icon()){
            return m("span",{
                class : "material-symbols-outlined mr-4"
            },[v.icon()]);
        }
        return "";
    }
    function label(v){
        if(v.label()){
            return m("span",{},[v.label()]);
        }
        return "";
    }

    let basePath = "~";

    function getBasePathByType(s){
        let m = am7model.getModel(s);
        if(!m || !m.group) return basePath;
        return basePath + "/" + m.group;
	}
	function getTypeByPath(sPath){
        let subPath = sPath.substring(sPath.lastIndexOf("/") + 1);
        let outT;
        let aP = Object.keys(paths).filter((k)=>{if(paths[k].substring(paths[k].lastIndexOf("/") + 1) == subPath) return true;});
        if(aP.length) outT = aP[0];
        if(!outT){
            let outP = am7model.getPrototype(subPath.toLowerCase());
            if(outP) outT = outP.key;
            //console.log(outP, outT);
        }
        return outT;
    }

    function getPathForType(type){
        let path = getBasePathByType(type);
        if(path != null) path = path.replace(/^~/, page.user.homeDirectory.path);
        return path;
    }

    let am7view = {
        form,
        label,
        icon,
        path: getBasePathByType,
        pathForType: getPathForType,
        basePath: (s) => {
            if(s){
                basePath = s;
            }
            return basePath;
        }
    };

    if (typeof module != "undefined") {
        module.am7view = am7view;
    } else {
        window.am7view = am7view;
    }
}());