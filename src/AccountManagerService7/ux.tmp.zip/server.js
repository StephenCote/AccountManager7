(function(){

const httpService = require("./server/httpService");
httpService.run();


}());