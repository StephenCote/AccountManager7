(function(){
    let am7Categories = {
        "identity" : {
            "label" : "Identity",
            "icon" : "account_tree",
            "order" : ["user","person","account","role","permission","contact","address"],
            "prototype" : {
                "application" : {
                    "pathName" : "Applications",
                    "type" : "group",
                    "childTypes" : ["data","group","permission","account"],
                    "icon" : "web_asset",
                    "order" : ["account","group","permission","data"]
                }
            }
        },
        "asset" : {
            "label" : "Assets",
            // "note",
            "order" : ["application","gallery","article", "data","group","tag"],
            "icon" : "emoji_objects",
            "prototype" : {
                "gallery" : {
                    "pathName" : "Gallery",
                    "childTypes" : ["data","group"],
                    "type" : "group",
                    "icon" : "collections",
                    "order" : ["group","data"]
                },
                "article" : {
                    "pathName" : "Articles",
                    "childTypes" : ["data","group"],
                    "type" : "group",
                    "icon" : "article",
                    "order" : ["group","data"]
                }

            }
        },
        /*
        "business" : {
            "label" : "Business",
            "order" : ["goal","budget","schedule","case","requirement","model","estimate"],
            "icon" : "business_center"
        },
        "process" : {
            "label" : "Process",
            "order" : ["request", "methodology","process","processstep"],
            "icon" : "insights"
        },
        "event" : {
            "label" : "Event",
            "order" : ["message", "location","event","trait"],
            "icon" : "event_note"
        },
        "project" : {
            "label" : "Project",
            "order" : ["lifecycle","project","stage","work","task"],
            "icon" : "dynamic_form"
        },
        */
        "policy" : {
            "label" : "Policy",
            "order" : ["policy","rule","pattern","fact","operation","function","request"],
            "icon" : "policy"
        },
        /*
        "resource" : {
            "label" : "Resources",
            "order" : ["artifact","resource","estimate","cost","time","module","ticket"],
            "icon" : "web_asset"
        },
        */
        // "form","formelement",
        "form" : {
            "label" : "Forms",
            "order" : ["validationrule"],
            "icon" : "dynamic_form"
        }
        
    };

    let am7ModelSupplement = {

        "account" : {icon : "account_circle", category : "application"},
        "address" : {icon : "maps_home_work", category : "identity"},
        "artifact" : {icon : "topic", category : "resource"},
        "group" : {label : "group", icon : "folder", category : "asset"},
        "permission" : {label : "permission", icon : "shield", category : "identity"},
        "role" : {label : "role", icon : "badge", category : "identity"},
        "tag" : {label : "tag", icon : "category", category : "asset"},
        "budget" : {icon : "percent", category : "business"},
        "case" : {icon : "flaky", category : "business"},
        "contact" : {icon : "contact_page", category : "identity"},
        "control" : { icon : "app_blocking", category : ""},
        "cost" : {icon : "attach_money", category : "resource"},
        //"credential" : { icon : "privacy_tip", category : ""},
        "data" : {icon : "data_object", category : "asset"},
        "estimate" : {icon : "show_chart", category : "business"},
        "event" : {icon : "event", category : "event"},
        "fact" : {icon : "fact_check", category : "policy"},
        "form" : {icon : "dynamic_form", category : "form"},
        "formelement" : {icon : "view_list", category : "form"},
        "function" : {icon : "functions", category : "policy"},
        "goal" : {icon : "flag", category : "business"},
        "lifecycle" : {icon : "hub", category : "project"},
        "location" : {icon : "location_on", category : "event"},
        "message" : { systemNew: true,icon : "chat_bubble", category : "event"},
        "methodology" : {icon : "timeline", category : "process"},
        "model" : {icon : "view_quilt", category : "business"},
        "module" : {icon : "view_module", category : "resource"},
        "note" : {icon : "note", category : "asset"},
        "operation" : {icon : "call_to_action", category : "policy"},
        "organization" : {icon : "public", category : ""},
        "pattern" : {icon : "texture", category : "policy"},
        "person" : {icon : "person", category : "identity"},
        "policy" : {icon : "policy", category : "policy"},
        "process" : {icon : "polyline", category : "process"},
        "processstep" : {icon : "developer_board", category : "process"},
        "project" : {icon : "spoke", category : "project"},
        "request" : { icon : "switch_access_shortcut", category : ""},
        "requirement" : {icon : "grading", category : "business"},
        "resource" : {icon : "web_asset", category : "resource"},
        "rule" : {icon : "rule", category : "policy"},
        "schedule" : {icon : "calendar_month", category : "business"},
        "stage" : {icon : "add_road", category : "project"},
        "task" : {icon : "task", category : "project"},
        "ticket" : {icon : "confirmation_number", category : "resource"},
        "time" : {icon : "schedule", category : "resource"},
        "trait" : {icon : "scatter_plot", category : "event"},
        "user" : {icon : "verified_user", category : "identity"},
        "validationrule" : {icon : "rule", category : "form"},
        "work" : {icon : "work", category : "project"}
    };

    window.am7model.categories = am7Categories;
    window.am7model.supplement = am7ModelSupplement;
}());