(function(){
    const mimeUtil = require("../common/mimeTypeUtil");
    const fs = require("fs");
    const express = require("express");
    const session = require("express-session");
    var compression = require('compression')
    const cors = require('cors');
    const {Client} = require("./client");
    const client = new Client();
    const {Config} = require("./config");
    const config = new Config();
    const passport = require("passport");
    const LocalStrategy = require("passport-local").Strategy;
    const bodyParser = require("body-parser");
    const authenticate = passport.authenticate("local", {
        failureFlash: "Username or password invalid",
        failWithError: true
    });

    const restricted = [
        "rest"
    ];
    
    let app = express();

    app.use(compression({filter: function(req, res) {
        if (req.headers['x-no-compression']) {
            return false
        }
        return compression.filter(req, res)
    }}));

    let secretSalt;
    let eventSessions = {};
    let sessions = {};
    let clients = {};
    let port;
    let mode;

    let sessionTimeout;
    let cfg;
    let clientCfg;
    let adminSession = "000-000-000-000";

    function init() {
        return new Promise(function (resolve, reject) {
            client.init("/server/client.json").then((config)=>{
                clientCfg = config;
                let ctx = client.newClientContext(config.adminOrganization,config.adminUser,adminSession);
                client.authenticate(ctx, config.adminCredential).then((token)=>{
                    clients[adminSession] = ctx;
                });
            });
            function getConfig() {
                return new Promise(function (resolve) {
                    config.read().then(function (resp) {
                        cfg = resp;
                        debug = Boolean(resp.debug);
    
                        // Default 1 day.
                        sessionTimeout = resp.sessionTimeout || 86400000;
                        secretSalt = resp.secret;
                        systemUser = resp.pgUser;
                        mode = resp.mode || "prod";
                        port = process.env.PORT || resp.clientPort || 80;
    
                        resolve();
                    });
                });
            }
    
            // Execute
            Promise.resolve().then(
                getConfig
            ).then(
                resolve
            ).catch(function (err) {
                console.log(err);
                reject(err);
            });
        });
    }
    function doGetFile(req, res) {
        let url = "." + req.url;
    
        let file = (req.url.match(/^\/$/) ? "index.html" : (req.params.file || ""));
        let suffix = (
            file
            ? file.slice(file.indexOf("."), file.length)
            : url.slice(url.lastIndexOf("."), url.length)
        );
        
        let mt = mimeUtil.findByExtension(suffix);

        let mimeType;
        if(mt) mimeType = {"Content-Type": mt};

        fs.readFile(url + file, function (err, resp) {
            if (err) {
                console.log("Woops: " + err);
                return;
            }
            if(mt && mt.match(/html$/)){
                //console.log(file + " : "  + resp.length);
                /*
                let str = resp.toString();
                if(str){
                    resp = Buffer.from(str.replace(/\%AM5_SERVER\%/gi,"http://localhost:8888"))
                }
                */
                
                resp = Buffer.from(resp.toString()
                    .replace(/\%AM7_SERVER\%/gi,clientCfg.am7server)
                );
                
            }
            res.writeHeader(200, mimeType);
            res.write(resp);
            res.end();
        });
    }
    
    function start() {

        app.use(bodyParser.urlencoded({
            extended: true
        }));
        app.use(bodyParser.json());
    
        // Set up authentication with passport
        passport.use(new LocalStrategy(
            function (username, password, done) {
                console.log("Login process:", username);
    
            }
        ));
    
        passport.serializeUser(function (user, done) {
            console.log("serialize ", user);
            done(null, user.name);
        });
    
        passport.deserializeUser(function (name, done) {
            console.log("deserialize ", name);
            datasource.deserializeUser(name).then(
                function (user) {
                    console.log("deserializeUser", user);
                    done(null, user);
                }
            ).catch(done);
        });
        function createId() {
            let x = 2147483648;
            let d = new Date();
            let result;
    
            result = Math.floor(Math.random() * x).toString(36);
            result += Math.abs(Math.floor(Math.random() * x) ^ d).toString(36);
    
            return result;
        }
        // Initialize passport
        app.use(express.static("public"));
        
        app.use(session({
    
            secret: secretSalt,
            resave: true,
            rolling: true,
            saveUninitialized: false,
            cookie: {
                secure: "auto",
                maxAge: sessionTimeout
            },
            genid: () => createId()
        }));
        app.use(bodyParser.urlencoded({extended: false}));
        app.use(passport.initialize());
        app.use(passport.session());
        
        app.use(cors({
            origin: ['http://localhost:8080','http://localhost:8899']
        }));

        app.use(function (req, res, handleUse) {

            let target = req.url.slice(1);
            // console.log("Use: " + target);

            let interval = req.session.cookie.expires - new Date();
            target = target.slice(0, target.indexOf("/"));
            if (!req.user && restricted.indexOf(target) !== -1) {
                res.status(401).json("Unauthorized session");
                return;
            }
    
            if (req.session && sessions[req.sessionID]) {
                clearTimeout(sessions[req.sessionID]);
            }
            if (req.user) {
                req.user.mode = mode;
                sessions[req.sessionID] = setTimeout(function () {
                    logger.verbose("Session " + req.sessionID + " timed out");

                }, interval);
            }
    
            handleUse();
        });
    
        // static pages
        app.get("/", doGetFile);
        cfg.directories.forEach((dirname) => app.get(dirname + "/:filename", doGetFile));
        cfg.files.forEach((filename) => app.get(filename, doGetFile));

        const server = app.listen(port);
    
        console.log("Listening on port: " + port);
    }

    function run(){    
        return init().then(start).catch(x=>{console.log("Caught error: " + x);process.exit();});
    }

    let httpService = {
        run : run,
        init : init,
        start : start,
        process : process
    };

    module.exports = httpService;
})();